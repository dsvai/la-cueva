/* ============================================================
   LA CUEVA · almacenamiento persistente
   Base de datos del artefacto (db) si está disponible; si no, este
   navegador (localStorage) o solo memoria. Todo pasa por aquí.
   ============================================================ */
const Store = (() => {
  // colecciones cargadas al arrancar; las pesadas (textos) se cargan bajo demanda
  const EAGER = ['config', 'agents', 'projects', 'convs', 'plans', 'tasks', 'approvals', 'rules', 'notes', 'deliverables', 'schedules', 'activity', 'usage', 'pdocs'];
  const LAZY = ['chunks', 'dtext', 'tthread', 'ptext'];
  const mem = {}; for (const c of EAGER.concat(LAZY)) mem[c] = new Map();
  let db = null, mode = 'memory', lastError = null;
  const queue = new Map(); let pumping = false;

  function useLocal() {
    try { const k = '__lc_probe'; localStorage.setItem(k, '1'); localStorage.removeItem(k); return true; } catch (e) { return false; }
  }
  async function init() {
    try {
      if (window.claude && typeof window.claude.use === 'function') db = await Promise.race([window.claude.use('db'), sleep(10000).then(() => null)]);
    } catch (e) { db = null; }
    if (db) {
      mode = 'db';
      for (const c of EAGER) {
        try {
          const snap = await db.collection(c).limit(1000).get();
          for (const d of snap.docs) if (d.exists) mem[c].set(d.id, Object.assign({}, d.data()));
        } catch (e) { lastError = e; console.warn('carga', c, e); if (e && (e.code === 'not_granted' || e.code === 'revoked')) { db = null; mode = useLocal() ? 'local' : 'memory'; break; } }
      }
    } else if (useLocal()) mode = 'local';
    if (mode === 'local') {
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i); if (!k || !k.startsWith('lc:')) continue;
        const [, c, id] = k.split(':'); if (!mem[c] || LAZY.includes(c)) continue;
        try { mem[c].set(id, JSON.parse(localStorage.getItem(k))); } catch (e) { }
      }
    }
    Bus.emit('store:ready', mode);
    return mode;
  }
  function all(c) { return [...mem[c].values()]; }
  function get(c, id) { return mem[c].get(id) || null; }
  function emit(c) { Bus.emit('store:' + c); Bus.emit('store:any', c); }
  /* escribe el documento entero (en memoria al instante, persistencia en cola) */
  function put(c, obj) {
    if (!obj.id) obj.id = uid(c.slice(0, 2));
    mem[c].set(obj.id, obj);
    enqueue(c, obj.id, obj); emit(c);
    return obj;
  }
  function patch(c, id, p) { const o = mem[c].get(id); if (!o) return null; Object.assign(o, p); enqueue(c, id, o); emit(c); return o; }
  function del(c, id) { mem[c].delete(id); enqueue(c, id, null); emit(c); }
  function enqueue(c, id, obj) {
    queue.set(c + '/' + id, { c, id, obj: obj ? JSON.parse(JSON.stringify(obj)) : null });
    if (!pumping) pump();
  }
  async function pump() {
    pumping = true;
    await sleep(250);
    while (queue.size) {
      const [k, job] = queue.entries().next().value; queue.delete(k);
      try { await writeOne(job); }
      catch (e) {
        lastError = e; console.warn('guardar', job.c, e);
        if (e && e.code === 'unavailable') { await sleep(800 + Math.random() * 800); try { await writeOne(job); } catch (e2) { Bus.emit('store:error', e2); } }
        else Bus.emit('store:error', e);
      }
    }
    pumping = false;
  }
  async function writeOne({ c, id, obj }) {
    if (mode === 'db') { const ref = db.collection(c).doc(id); if (obj) await ref.set(obj); else await ref.delete(); }
    else if (mode === 'local') { const k = 'lc:' + c + ':' + id; try { if (obj) localStorage.setItem(k, JSON.stringify(obj)); else localStorage.removeItem(k); } catch (e) { throw { code: 'quota_exceeded', message: 'El almacenamiento de este navegador está lleno.' }; } }
  }
  /* documentos perezosos (textos largos) */
  async function load(c, id) {
    if (mem[c].has(id)) return mem[c].get(id);
    let v = null;
    try {
      if (mode === 'db') { const s = await db.collection(c).doc(id).get(); if (s.exists) v = Object.assign({}, s.data()); }
      else if (mode === 'local') { const raw = localStorage.getItem('lc:' + c + ':' + id); if (raw) v = JSON.parse(raw); }
    } catch (e) { lastError = e; }
    if (v) mem[c].set(id, v);
    return v;
  }
  async function loadWhere(c, field, value) {
    const out = [];
    try {
      if (mode === 'db') { const s = await db.collection(c).where(field, '==', value).limit(500).get(); for (const d of s.docs) { const v = Object.assign({}, d.data()); mem[c].set(d.id, v); out.push(v); } return out; }
      if (mode === 'local') { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k && k.startsWith('lc:' + c + ':')) { try { const v = JSON.parse(localStorage.getItem(k)); if (v && v[field] === value) { mem[c].set(v.id, v); out.push(v); } } catch (e) { } } } return out; }
    } catch (e) { lastError = e; }
    return all(c).filter(v => v[field] === value);
  }
  function pending() { return queue.size + (pumping ? 1 : 0); }
  /* copia de seguridad completa (incluye textos ya cargados) */
  async function exportAll() {
    const out = { app: 'La Cueva', version: 1, exportedAt: new Date().toISOString(), data: {} };
    for (const d of all('deliverables')) await load('dtext', d.id);
    for (const cv of all('convs')) for (let n = 0; n < (cv.chunks || 1); n++) await load('chunks', cv.id + '-' + n);
    for (const p of all('pdocs')) await load('ptext', p.id);
    for (const c of EAGER.concat(LAZY)) out.data[c] = all(c);
    return out;
  }
  async function importAll(json) {
    if (!json || json.app !== 'La Cueva' || !json.data) throw new Error('El archivo no es una copia de La Cueva.');
    for (const c of Object.keys(json.data)) { if (!mem[c]) continue; for (const o of json.data[c]) if (o && o.id) put(c, o); }
  }
  return { init, all, get, put, patch, del, load, loadWhere, pending, exportAll, importAll, get mode() { return mode; }, get lastError() { return lastError; } };
})();

/* ---------- registro de actividad real y consumo ---------- */
const Activity = (() => {
  const live = new Map();     // llamadas de IA en curso: id -> {agentId, kind, label, taskId, started}
  function log(kind, text, ref) {
    const k = dayKey(); const doc = Store.get('activity', k) || { id: k, events: [] };
    doc.events.push(Object.assign({ ts: Date.now(), kind, text }, ref || {}));
    if (doc.events.length > 1500) doc.events = doc.events.slice(-1500);
    Store.put('activity', doc);
  }
  function recent(n) { const out = []; const days = Store.all('activity').sort((a, b) => b.id.localeCompare(a.id)); for (const d of days) { for (let i = d.events.length - 1; i >= 0; i--) { out.push(d.events[i]); if (out.length >= n) return out; } } return out; }
  function usage(agentId, projectId, inTok, outTok) {
    const k = dayKey(); const u = Store.get('usage', k) || { id: k, calls: 0, inTok: 0, outTok: 0, byAgent: {}, byProject: {} };
    u.calls++; u.inTok += inTok; u.outTok += outTok;
    const a = u.byAgent[agentId] || (u.byAgent[agentId] = { calls: 0, inTok: 0, outTok: 0 }); a.calls++; a.inTok += inTok; a.outTok += outTok;
    const pk = projectId || '_general'; const p = u.byProject[pk] || (u.byProject[pk] = { calls: 0, inTok: 0, outTok: 0 }); p.calls++; p.inTok += inTok; p.outTok += outTok;
    Store.put('usage', u);
  }
  function today() { return Store.get('usage', dayKey()) || { calls: 0, inTok: 0, outTok: 0, byAgent: {}, byProject: {} }; }
  function start(info) { const id = uid('live'); live.set(id, Object.assign({ started: Date.now() }, info)); Bus.emit('live'); return id; }
  function end(id) { live.delete(id); Bus.emit('live'); }
  return { log, recent, usage, today, start, end, live };
})();
